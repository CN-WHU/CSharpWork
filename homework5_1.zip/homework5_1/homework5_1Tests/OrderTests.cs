﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using homework6_1;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace homework6_1.Tests
{
    [TestClass()]
    public class OrderTests
    {
        [TestMethod()]
        public void OrderTest()
        {
            Assert.Fail();
        }
    }
}